function openSettings(){
    for (let i of Object.keys(keyMap)){
        delete keyMap[i];
    }

    document.body.removeChild(document.getElementById("mainTemplate"));

    keyMap["i"] = function(){location.reload()}
    keyMap["escape"] = function(){location.reload()}
    document.getElementById("settingsButton").setAttribute("onclick", "location.reload()");

    let settingsTemplate = document.createElement("div");
    settingsTemplate.setAttribute("id", "settingsTemplate");

    {
        let settingsHeader = document.createElement("h1");
        settingsHeader.setAttribute("id", "settingsHeader");
        settingsHeader.innerHTML = "Settings";

        settingsTemplate.appendChild(settingsHeader);
    }

    {
        let setParamDiv = document.createElement("div");
        
        let paramElStart = document.createElement("input");
        let paramElEnd = document.createElement("input");

        paramElStart.setAttribute("type", "number");
        paramElEnd.setAttribute("type", "number");

        paramElStart.setAttribute("class", "settingsInputBox");
        paramElEnd.setAttribute("class", "settingsInputBox");

        let setParamInfo = document.createElement("h2");
        setParamInfo.innerHTML = "select a range from the initial list. (1 - 1'000)";
        setParamInfo.setAttribute("id", "settingParamInfo");

        setParamDiv.appendChild(paramElStart);
        setParamDiv.appendChild(paramElEnd);
        setParamDiv.appendChild(setParamInfo);

        let paramHeader = document.createElement("h1");
        paramHeader.innerHTML = "Set parameters";

        settingsTemplate.appendChild(paramHeader);
        settingsTemplate.appendChild(setParamDiv);
    }

    {
        let changeMultiGuessDiv = document.createElement("div");

        let multiGuessInput = document.createElement("input");
        multiGuessInput.setAttribute("class", "settingsInputBox");
        multiGuessInput.setAttribute("type", "number");
        let multiGuessInfo = document.createElement("h2");
        multiGuessInfo.innerHTML = "select how many words you guess from in the multi guess gamemode (1 - 8) (4 is standard)";

        changeMultiGuessDiv.appendChild(multiGuessInput);
        changeMultiGuessDiv.appendChild(multiGuessInfo);

        let changeMultiHeader = document.createElement("h1");
        changeMultiHeader.style.marginTop = "50px";
        changeMultiHeader.innerHTML = "Change multi guess buttons";

        settingsTemplate.appendChild(changeMultiHeader);
        settingsTemplate.appendChild(changeMultiGuessDiv);
    }

    {
        let changeSearchLenDiv = document.createElement("div");

        let searchInput = document.createElement("input");
        searchInput.setAttribute("class", "settingsInputBox");
        searchInput.setAttribute("type", "number");
        let searchInfo = document.createElement("h2");
        searchInfo.innerHTML = "select how many search options pop up for the written guess game (5 is standard)";

        changeSearchLenDiv.appendChild(searchInput);
        changeSearchLenDiv.appendChild(searchInfo);

        let searchHeader = document.createElement("h1");
        searchHeader.style.marginTop = "50px";
        searchHeader.innerHTML = "Change search result count";

        settingsTemplate.appendChild(searchHeader);
        settingsTemplate.appendChild(changeSearchLenDiv);
    }

    {
        let settingsButtonsDiv = document.createElement("div");
        settingsButtonsDiv.setAttribute("id", "settingsButtonsDiv")
        
        let applySettings = document.createElement("button");
        let resetSettings = document.createElement("button");

        applySettings.setAttribute("class", "settingsMenuButtons");
        resetSettings.setAttribute("class", "settingsMenuButtons");

        applySettings.setAttribute("onclick", "applySettings()");
        resetSettings.setAttribute("onclick", "resetSettings()");

        applySettings.innerHTML = "Apply settings";
        resetSettings.innerHTML = "Reset settings";

        settingsButtonsDiv.appendChild(applySettings);
        settingsButtonsDiv.appendChild(resetSettings);
        settingsTemplate.appendChild(settingsButtonsDiv);
    }
    
    document.body.appendChild(settingsTemplate);
}

function applySettings(){
    let settingsButtons = document.getElementsByClassName("settingsInputBox");
    
    let param0 = Math.floor(Number(settingsButtons[0].value)) - 1;
    let param1 = Math.floor(Number(settingsButtons[1].value));
    let multiCount = Math.floor(Number(settingsButtons[2].value));
    let searchLen = Math.floor(Number(settingsButtons[3].value));

    for (;;){
        if (typeof param0 != "number" || typeof param1 != "number"){
            break;
        }

        if (param0 < 0 || param0 > 1000){
            break;
        }

        if (param1 < 0 || param1 > 1000){
            break;
        }

        if (param1 - param0 < 6){
            break;
        }

        localStorage.wordParameters = param0.toString() + "," + param1.toString();
        break;
    }

    if (typeof multiCount == "number" && multiCount < 9 && multiCount > 0){
        localStorage.multiGuessCount = multiCount.toString();
    }

    if (typeof searchLen == "number" && searchLen >= 0 && settingsButtons[3].value != ""){
        localStorage.searchBarLength = searchLen.toString();
    }

    location.reload();
}

function resetSettings(){
    delete localStorage.languageIds;
    delete localStorage.multiGuessCount;
    delete localStorage.selectedGame;
    delete localStorage.wordParameters;
    delete localStorage.searchBarLength;

    location.reload();
}