var defaultKeyVal = [
    "numLayout", "1",
    "languageIds", "000",
    "wordParameters", "0,1000",
    "selectedGame", "0",
    "multiGuessCount", "4",
    "searchBarLength", "5"
];

for (let i = 0; i < defaultKeyVal.length; i += 2){
    if (!(defaultKeyVal[i] in localStorage)){
        localStorage[defaultKeyVal[i]] = defaultKeyVal[i + 1];
    }
}

/*
if (!("numLayout" in localStorage)){
    localStorage.numLayout = 1;
}

if (!("languageIds" in localStorage)){
    localStorage.languageIds = "000";
}

if (!("wordParameters" in localStorage)){
    localStorage.wordParameters = "0,1000";
}

if (!("selectedGame" in localStorage)){
    localStorage.selectedGame = "0";
}

if (!("multiGuessCount" in localStorage)){
    localStorage.multiGuessCount = "4";
}

if (!("searchBarLength" in localStorage)){
    localStorage.searchBarLength = "5";
}
*/
let selectedGame = Number(localStorage.selectedGame);

var langMode;

var primaryList;
var secondaryList;

var keyMap = {
    "1": function(){highlightNew(0)},
    "2": function(){highlightNew(1)},
    "3": function(){highlightNew(2)},
    "4": function(){highlightNew(3)},
    i: openSettings,
    k: function(){changeLangMode(selectedGame)},
    l: function(){swapLangMode(selectedGame)},
    enter: function(){startGame(selectedGame)},
    " ": function(){startGame(selectedGame)},
    arrowup: function(){moveBy(-1)},
    arrowdown: function(){moveBy(1)},
}

currentKeyMap = keyMap;

let lowerInputFunction = function(){}

document.addEventListener("keydown", function(e){
    let key = e.key.toLowerCase();
    lowerInputFunction(e);

    if (key == "escape"){
        e.preventDefault();
    }

    if (key in currentKeyMap){
        currentKeyMap[key]();
    }
});

function highlightNew(index){
    let buttons = document.getElementsByClassName("gameButton");
    buttons[selectedGame].style.borderColor = "#151515";
    buttons[index].style.borderColor = "red";
    selectedGame = index;
    localStorage.selectedGame = index.toString();
}

highlightNew(selectedGame);

function moveBy(n){
    let newSel = (selectedGame + n) % 4;

    if (newSel == -1){
        highlightNew(3);
    }
    else {
        highlightNew(newSel);
    }
}

languageModes = [
    ["漢字 / Rōmaji", "English"],
    ["漢字", "English"],
    ["漢字", "Rōmaji"],
    
    ["English", "漢字 / Rōmaji"],
    ["English", "漢字"],
    ["Rōmaji", "漢字"]
];

function updateButton(index){
    document.getElementsByClassName("langMode")[index].innerHTML = languageModes[localStorage.languageIds[index]][0] + " <span style='color: white'>to</span> " + languageModes[localStorage.languageIds[index]][1];
}

function changeLangMode(index){
    if (index > 2){
        return;
    }

    if (localStorage.languageIds[index] == 2){
        localStorage.languageIds = localStorage.languageIds.slice(0, index) + "0" + localStorage.languageIds.slice(index + 1);
    }
    else if (localStorage.languageIds[index] == 5){
        localStorage.languageIds = localStorage.languageIds.slice(0, index) + "3" + localStorage.languageIds.slice(index + 1);
    }
    else {
        localStorage.languageIds = localStorage.languageIds.slice(0, index) + (Number(localStorage.languageIds[index]) + 1) + localStorage.languageIds.slice(index + 1);
    }

    updateButton(index);
}

function swapLangMode(index){
    if (index > 2){
        return;
    }

    localStorage.languageIds = localStorage.languageIds.slice(0, index) + (Number(localStorage.languageIds[index]) + 3) % 6 + localStorage.languageIds.slice(index + 1);

    updateButton(index);
}

function mChangeLangMode(e, index){
    changeLangMode(index);
    highlightNew(index);
    e.stopPropagation();
}

function mSwapLangMode(e, index){
    swapLangMode(index);
    highlightNew(index);
    e.stopPropagation();
}

function mClickButton(index){
    highlightNew(index);
    startGame(index);
}

function startGame(index){
    if (index != 3){
        kanjiLibrary = kanjiLibrary.slice(firstParam, secondParam);
        romajiLibrary = romajiLibrary.slice(firstParam, secondParam);
        englishLibrary = englishLibrary.slice(firstParam, secondParam);
    }

    for (let i of Object.keys(keyMap)){
        delete keyMap[i];
    }

    keyMap["escape"] = function(){location.reload()}

    langMode = localStorage.languageIds[index];

    document.body.removeChild(document.getElementById("mainTemplate"));
    document.body.removeChild(document.getElementById("settingsButton"));

    [
        flashCardStart,
        multiGuessStart,
        writtenGuessStart,
        phrasesListStart,
        function(){},
    ][index]();
}

function setGameLists0(){
    let temp0;
    let temp1;

    if (langMode % 3 == 0){
        temp0 = [];

        for (let i = 0; i < kanjiLibrary.length; i++){
            temp0.push("<span style='color: #44FFBB'>" + kanjiLibrary[i] + "</span> &nbsp" + romajiLibrary[i]);
        }

        temp1 = englishLibrary;
    }
    else if (langMode % 3 == 1){
        temp0 = kanjiLibrary;
        temp1 = englishLibrary;
    }
    else {
        temp0 = kanjiLibrary;
        temp1 = romajiLibrary;
    }

    if (langMode < 3){
        primaryList = temp0;
        secondaryList = temp1;
    }
    else {
        primaryList = temp1;
        secondaryList = temp0;
    }
}

function endGame(){
    let endScreen = document.createElement("h1");
    let subEndScreen = document.createElement("h1");

    endScreen.setAttribute("id", "endScreen");
    subEndScreen.setAttribute("id", "subEndScreen");
    
    endScreen.innerHTML = "Game over!";
    subEndScreen.innerHTML = "You got " + correctGuesses + "/" + (secondParam - firstParam) + " from the selected range: (" + (firstParam + 1) + " - " + secondParam + "), good job!<br>Press esc to return";

    document.body.appendChild(endScreen);
    document.body.appendChild(subEndScreen);
}

function flashCardStart(){
    setGameLists0();

    let newMainTemplate = document.createElement("div");
    newMainTemplate.setAttribute("id", "flashCardTemplate");

    let flashCard = document.createElement("div");
    flashCard.setAttribute("id", "flashCard");
    flashCard.setAttribute("onclick", "flipCard()");

    let flashText = document.createElement("p");

    flashCard.appendChild(flashText);
    newMainTemplate.appendChild(flashCard);

    let cardBrowser = document.createElement("div");
    cardBrowser.setAttribute("id", "flashCardBrowser");

    let buttonLeft = document.createElement("button");
    let buttonRight = document.createElement("button");
    let cardCounter = document.createElement("button");

    
    buttonLeft.innerHTML = "<";
    buttonRight.innerHTML = ">";
    
    buttonLeft.setAttribute("class", "flashCardButton");
    buttonRight.setAttribute("class", "flashCardButton");
    cardCounter.setAttribute("id", "cardCounter");

    buttonLeft.setAttribute("onclick", "moveCard(-1)");
    buttonRight.setAttribute("onclick", "moveCard(1)");

    cardBrowser.appendChild(buttonLeft);
    cardBrowser.appendChild(cardCounter);
    cardBrowser.appendChild(buttonRight);

    newMainTemplate.appendChild(cardBrowser);

    document.body.appendChild(newMainTemplate);

    window.cardIndex = 0;
    window.cardShown = secondaryList[0];
    window.cardHidden = primaryList[0];

    flipCard();
    cardCounter.innerHTML = (cardIndex + 1).toString() + " / " + (secondParam - firstParam).toString();

    keyMap[" "] = flipCard;
    keyMap["arrowup"] = flipCard;
    keyMap["arrowdown"] = flipCard;

    keyMap["arrowleft"] = function(){moveCard(-1)};
    keyMap["arrowright"] = function(){moveCard(1)};
}

function flipCard(){
    let temp = cardShown;
    cardShown = cardHidden;
    cardHidden = temp;

    document.getElementById("flashCard").children[0].innerHTML = cardShown;
}

function moveCard(n){
    if ((cardIndex == 0 && n == -1) || (cardIndex == secondParam - firstParam - 1 && n == 1)){
        return;
    }

    cardIndex += n;

    cardShown = secondaryList[cardIndex];
    cardHidden = primaryList[cardIndex];

    flipCard();
    cardCounter.innerHTML = (cardIndex + 1).toString() + " / " + (secondParam - firstParam).toString();
}

function multiGuessStart(){
    window.correctGuesses = 0;
    setGameLists0();

    for (let i = 0; i < primaryList.length; i++){
        primaryList[i] += "$" + i.toString();
    }

    let newMainTemplate = document.createElement("div");
    newMainTemplate.setAttribute("id", "multiGuessTemplate");

    let currentWordDiv = document.createElement("div");
    currentWordDiv.setAttribute("id", "multiCurrentWordDiv");

    let currentText = document.createElement("p");

    currentWordDiv.appendChild(currentText);
    newMainTemplate.appendChild(currentWordDiv);

    let buttonsDiv = document.createElement("div");
    buttonsDiv.setAttribute("id", "multiButtonsDiv");

    window.multiGuessCount = Number(localStorage.multiGuessCount);
    window.correctIndex;
    window.guessed = false;
    let numLay = Number(localStorage.numLayout);
    
    for (let i = 0; i < multiGuessCount; i++){
        let button = document.createElement("button");
        button.setAttribute("class", "multiGuessButton");
        button.setAttribute("onclick", "clickMultiGuess(" + i.toString() + ")");
        buttonsDiv.appendChild(button);

        keyMap[(i + numLay).toString()] = function(){clickMultiGuess(i)};
    }

    let scoreCounter = document.createElement("p");
    scoreCounter.setAttribute("id", "scoreCounter");

    newMainTemplate.appendChild(scoreCounter);
    newMainTemplate.appendChild(buttonsDiv);
    document.body.appendChild(newMainTemplate);
    nextMultiGuess();
}

function nextMultiGuess(){
    if (primaryList.length == 0){
        document.body.removeChild(document.getElementById("multiGuessTemplate"));
        endGame();
        return;
    }

    updateScore();
    
    for (let i = 0; i < multiGuessCount; i++){
        document.getElementsByClassName("multiGuessButton")[i].style.borderColor = "#151515";
    }
    
    let randIndex = Math.floor(Math.random() * primaryList.length);
    let currentWord = primaryList.splice(randIndex, 1)[0];
    let dollarIndex = currentWord.indexOf("$");

    document.getElementById("multiCurrentWordDiv").children[0].innerHTML = currentWord.slice(0, dollarIndex);

    let buttonsList = secondaryList.slice();
    let correctTranslated = buttonsList.splice(Number(currentWord.slice(dollarIndex + 1)), 1)[0];
    
    correctIndex = Math.floor(Math.random() * multiGuessCount);

    for (let i = 0; i < multiGuessCount; i++){
        if (i == correctIndex){
            continue;
        }

        let buttonInnerHTML = "";

        do {
            let randIndex = Math.floor(Math.random() * buttonsList.length);
            buttonInnerHTML = buttonsList.splice(randIndex, 1)[0];
        } while (buttonInnerHTML == correctTranslated);

        document.getElementsByClassName("multiGuessButton")[i].innerHTML = buttonInnerHTML;
    }

    document.getElementsByClassName("multiGuessButton")[correctIndex].innerHTML = correctTranslated;
}

function clickMultiGuess(n){
    if (guessed){
        guessed = false;
        nextMultiGuess();
        return;
    }

    guessed = true;
    
    if (n == correctIndex){
        correctGuesses++;
        document.getElementsByClassName("multiGuessButton")[n].style.borderColor = "#00FF00";
        return;
    }
    
    document.getElementsByClassName("multiGuessButton")[n].style.borderColor = "red";
    document.getElementsByClassName("multiGuessButton")[correctIndex].style.borderColor = "#00FF00";
}

function updateScore(){
    document.getElementById("scoreCounter").innerHTML = correctGuesses.toString() + " / " + (secondaryList.length - primaryList.length) + " / " + secondaryList.length;
}

function writtenGuessStart(){
    window.correctGuesses = 0;
    window.guessed = false;
    window.searchBarLen = Number(localStorage.searchBarLength);
    
    let newMainTemplate = document.createElement("div");
    newMainTemplate.setAttribute("id", "multiGuessTemplate");

    let currentWordDiv = document.createElement("div");
    currentWordDiv.setAttribute("id", "multiCurrentWordDiv");

    let currentText = document.createElement("p");

    currentWordDiv.appendChild(currentText);

    let searchBar = document.createElement("input");
    searchBar.setAttribute("id", "searchBar");
    searchBar.setAttribute("type", "text");
    
    let searchResults = document.createElement("div");
    searchResults.setAttribute("id", "searchResults");

    searchBar.addEventListener("input", updateSearchBar);
    
    for (let i = 0; i < searchBarLen; i++){
        let p = document.createElement("p");
        searchResults.appendChild(p);
    }

    let actualCorrectEl = document.createElement("h2");
    actualCorrectEl.setAttribute("id", "showCorrectAnswer");
    
    let whatMode = document.createElement("p");
    
    let scoreCounter = document.createElement("p");
    scoreCounter.setAttribute("id", "scoreCounter");

    newMainTemplate.appendChild(scoreCounter);
    
    newMainTemplate.appendChild(currentWordDiv);
    newMainTemplate.appendChild(whatMode);
    newMainTemplate.appendChild(searchBar);
    newMainTemplate.appendChild(searchResults);
    newMainTemplate.appendChild(actualCorrectEl);

    document.body.appendChild(newMainTemplate);
    
    searchBar.focus();
    
    keyMap["enter"] = enterWrittenWord;

    let numLay = Number(localStorage.numLayout);
    for (let i = 0; i < 5; i++){
        keyMap[(i + numLay).toString()] = function(){
            selectIndexForSearch(i);
        }
    }

    for (let i = 0; i < document.getElementById("searchResults").children.length; i++){
        document.getElementById("searchResults").children[i].setAttribute("onclick",
            "selectIndexForSearch(" + i + ")"
        );

        document.getElementById("searchResults").children[i].setAttribute("class", "searchBarLines");
    }
    
    if (langMode != 3){
        setGameLists0();

        for (let i = 0; i < primaryList.length; i++){
            primaryList[i] += "$" + i.toString();
        }

        lowerInputFunction = function(e){
            if ("12345".indexOf(e.key) != -1){
                e.preventDefault();
            }
        }
        nextWrittenWord();
        return;
    }

    window.isKanji = false;
    whatMode.setAttribute("id", "whatModeTab");
    whatMode.innerHTML = "漢字 &nbsp &nbsp &nbsp <span style='color: red'>Rōmaji</span>";
    whatMode.setAttribute("onclick", "switchLangTab()");
    
    primaryList = englishLibrary;
    secondaryList = romajiLibrary;
    window.ternaryList = kanjiLibrary;

    for (let i = 0; i < primaryList.length; i++){
        primaryList[i] += "$" + i.toString();
    }
    
    lowerInputFunction = function(e){
        if (e.key == "Tab"){
            e.preventDefault();
            switchLangTab();
        }
        else if ("12345".indexOf(e.key) != -1){
            e.preventDefault();
        }
        
    }

    nextWrittenWord();
}

function selectIndexForSearch(index){
    document.getElementById("searchBar").value = document.getElementById("searchResults").children[index].innerHTML;
    updateSearchBar();
}

function switchLangTab(){
    if (isKanji){
        document.getElementById("whatModeTab").innerHTML = "漢字 &nbsp &nbsp &nbsp <span style='color: red'>Rōmaji</span>";
        isKanji = false;
    }
    else {
        document.getElementById("whatModeTab").innerHTML = "<span style='color: red'>漢字</span> &nbsp &nbsp &nbsp Rōmaji";
        isKanji = true;
    }

    let temp = secondaryList.slice();
    secondaryList = ternaryList.slice();
    ternaryList = temp;

    document.getElementById("searchBar").value = "";
    updateSearchBar();
}

function updateSearchBar(){
    let spacesFilled = 0;

    for (let i = 0; i < document.getElementById("searchResults").children.length; i++){
        document.getElementById("searchResults").children[i].innerHTML = "";
    }
    
    let currentlyTyped = document.getElementById("searchBar").value;
    
    for (let i = 0; i < secondaryList.length && spacesFilled < searchBarLen; i++){
        if (secondaryList[i].slice(0, currentlyTyped.length).toLowerCase() == currentlyTyped.toLowerCase()){
            document.getElementById("searchResults").children[spacesFilled].innerHTML = secondaryList[i];
            spacesFilled++;
        }
    }
}

function nextWrittenWord(){
    if (primaryList.length == 0){
        document.body.removeChild(document.getElementById("multiGuessTemplate"));
        endGame();
        return;
    }

    updateScore();

    document.getElementById("showCorrectAnswer").style.opacity = 0;
    document.getElementById("searchResults").style.opacity = 1;
    
    document.getElementById("searchBar").style.color = "white";
    document.getElementById("searchBar").value = "";
    
    let randIndex = Math.floor(Math.random() * primaryList.length);
    let currentWord = primaryList.splice(randIndex, 1)[0];
    let dollarIndex = currentWord.indexOf("$");

    document.getElementById("multiCurrentWordDiv").children[0].innerHTML = currentWord.slice(0, dollarIndex);

    window.correctIndex = Number(currentWord.slice(dollarIndex + 1));
    
    updateSearchBar();
}

function enterWrittenWord(){
    if (guessed){
        guessed = false;
        nextWrittenWord();
        return;
    }
    
    if (document.getElementById("searchBar").value.length == 0){
        return;
    }
    
    document.getElementById("searchResults").style.opacity = 0;
    guessed = true;

    if (document.getElementById("searchBar").value.toLowerCase() == secondaryList[correctIndex].toLowerCase()){
        correctGuesses++;
        document.getElementById("searchBar").style.color = "#00FF00";
        return;
    }
    document.getElementById("showCorrectAnswer").innerHTML = secondaryList[correctIndex];
    document.getElementById("showCorrectAnswer").style.opacity = 1;
    document.getElementById("searchBar").style.color = "red";
}

{
    let commaIndex = localStorage.wordParameters.indexOf(",");

    var firstParam = Number(localStorage.wordParameters.slice(0, commaIndex));
    var secondParam = Number(localStorage.wordParameters.slice(commaIndex + 1));
}

document.getElementById("wordParamDisplay").innerHTML = "(" + (Number(firstParam) + 1) + " - " + secondParam + ")";

function scrollUpFunc(){
    document.getElementsByClassName("phraseListSection")[0].scrollIntoView();
}

function phrasesListStart(){

    let newMainTemplate = document.createElement("div");
    newMainTemplate.setAttribute("id", "phraseList");

    let scrollUp = document.createElement("button");
    scrollUp.setAttribute("id", "scrollUp");
    scrollUp.setAttribute("onclick", "scrollUpFunc()");
    scrollUp.innerHTML = "^";

    keyMap["1"] = scrollUpFunc;

    newMainTemplate.appendChild(scrollUp);

    let darkDash = "<span style='color: #101010'>-</span>";

    for (let i = 0; i < kanjiLibrary.length; i++){
        let section = document.createElement("div");
        section.setAttribute("class", "phraseListSection");

        let p0 = document.createElement("p");
        p0.style.width = "100px";
        p0.style.color = "#606060";
        p0.innerHTML = darkDash + (i + 1).toString() + darkDash;

        let p1 = document.createElement("p");
        p1.style.width = "300px";
        p1.innerHTML = darkDash + kanjiLibrary[i] + darkDash;
        
        let p2 = document.createElement("p");
        p2.style.width = "300px";
        p2.innerHTML = darkDash + romajiLibrary[i] + darkDash;
        
        let p3 = document.createElement("p");
        p3.style.width = "500px";
        p3.innerHTML = darkDash + englishLibrary[i] + darkDash;

        section.appendChild(p0);
        section.appendChild(p1);
        section.appendChild(p2);
        section.appendChild(p3);

        newMainTemplate.appendChild(section);
    }

    document.body.append(newMainTemplate);

    let phraseSections = document.getElementsByClassName("phraseListSection");

    for (let i = firstParam; i < secondParam; i++){
        phraseSections[i].style.borderLeft = "2px solid #AA0000";
        phraseSections[i].style.borderRight = "2px solid #AA0000";
    }

    phraseSections[firstParam].style.borderTop = "2px solid #AA0000";
    phraseSections[secondParam - 1].style.borderBottom = "2px solid #AA0000";

    document.getElementsByClassName("phraseListSection")[firstParam].scrollIntoView();
}

for (let i = 0; i < 3; i++){
    updateButton(i);
}